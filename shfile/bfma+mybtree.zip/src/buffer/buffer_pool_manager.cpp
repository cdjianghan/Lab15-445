//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// buffer_pool_manager.cpp
//
// Identification: src/buffer/buffer_pool_manager.cpp
//
// Copyright (c) 2015-2019, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/buffer_pool_manager.h"

#include <list>
#include <unordered_map>

namespace bustub {

BufferPoolManager::BufferPoolManager(size_t pool_size, DiskManager *disk_manager, LogManager *log_manager)
    : pool_size_(pool_size), disk_manager_(disk_manager), log_manager_(log_manager) {
  // We allocate a consecutive memory space for the buffer pool.
  pages_ = new Page[pool_size_];
  replacer_ = new LRUReplacer(pool_size);

  // Initially, every page is in the free list.
  for (size_t i = 0; i < pool_size_; ++i) {
    free_list_.emplace_back(static_cast<int>(i));
  }
}

BufferPoolManager::~BufferPoolManager() {
  delete[] pages_;
  delete replacer_;
}

Page *BufferPoolManager::FetchPageImpl(page_id_t page_id) {
  // 1.     Search the page table for the requested page (P).
  // 1.1    If P exists, pin it and return it immediately.
  // 1.2    If P does not exist, find a replacement page (R) from either the free list or the replacer.
  //        Note that pages are always found from the free list first.
  // 2.     If R is dirty, write it back to the disk.
  // 3.     Delete R from the page table and insert P.
  // 4.     Update P's metadata, read in the page content from disk, and then return a pointer to P.
  latch_.lock();
  // exists
  for (size_t i = 0; i < GetPoolSize(); i++) {
    if (pages_[i].GetPageId() == page_id) {
      pages_[i].pin_count_++;
      replacer_->Pin(i);
      // LOG_DEBUG("buffer page id is %d, pin count is %d", page_id, pages_[i].GetPinCount());
      latch_.unlock();
      return pages_ + i;
    }
  }
  // don't exist
  bool ans = false;
  frame_id_t frame = -1;
  if (!free_list_.empty()) {
    ans = true;
    frame = free_list_.front();
    free_list_.pop_front();
  } else if (replacer_->Victim(&frame)) {
    ans = true;
    if (pages_[frame].IsDirty()) {
      FlushPageImplNoLock(INVALID_PAGE_ID, frame);
    }
  }
  if (ans) {
    pages_[frame].page_id_ = page_id;
    pages_[frame].pin_count_ = 1;
    pages_[frame].is_dirty_ = false;
    // LOG_DEBUG("read page is %d", page_id);
    disk_manager_->ReadPage(page_id, pages_[frame].GetData());
  }
  latch_.unlock();
  if (!ans) {
    return nullptr;
  }
  return pages_ + frame;
}

bool BufferPoolManager::UnpinPageImpl(page_id_t page_id, bool is_dirty) {
  bool ans = false;
  latch_.lock();
  for (size_t i = 0; i < GetPoolSize(); i++) {
    if (pages_[i].GetPageId() == page_id) {
      if (pages_[i].GetPinCount() > 0) {
        ans = true;
        if (is_dirty) {
          pages_[i].is_dirty_ = true;
        }
        pages_[i].pin_count_--;
        // LOG_DEBUG("unpin page id is %d, pin count is %d", page_id, pages_[i].pin_count_);
        if (pages_[i].GetPinCount() == 0) {
          replacer_->Unpin(i);
        }
      } else if (pages_[i].GetPinCount() <= 0) {
        LOG_DEBUG("page id is %d", pages_[i].GetPageId());
        DebugPrint();
        throw new Exception("pin count < 0");
      }
    }
  }
  latch_.unlock();
  return ans;
}

bool BufferPoolManager::FlushPageImpl(page_id_t page_id) {
  // Make sure you call DiskManager::WritePage!
  latch_.lock();
  bool ans = FlushPageImplNoLock(page_id, -1);
  latch_.unlock();
  return ans;
}

bool BufferPoolManager::FlushPageImplNoLock(page_id_t page_id, frame_id_t frame_id) {
  // Make sure you call DiskManager::WritePage!
  if (frame_id == -1) {
    for (size_t i = 0; i < GetPoolSize(); i++) {
      if (pages_[i].GetPageId() == page_id) {
        disk_manager_->WritePage(page_id, pages_[i].GetData());
        return true;
      }
    }
  }
  if (page_id == INVALID_PAGE_ID) {
    disk_manager_->WritePage(pages_[frame_id].GetPageId(), pages_[frame_id].GetData());
    return true;
  }
  return false;
}

Page *BufferPoolManager::NewPageImpl(page_id_t *page_id) {
  // 0.   Make sure you call DiskManager::AllocatePage!
  // 1.   If all the pages in the buffer pool are pinned, return nullptr.
  // 2.   Pick a victim page P from either the free list or the replacer. Always pick from the free list first.
  // 3.   Update P's metadata, zero out memory and add P to the page table.
  // 4.   Set the page ID output parameter. Return a pointer to P.
  latch_.lock();
  if (free_list_.empty() && replacer_->Size() == 0U) {
    latch_.unlock();
    return nullptr;
  }
  frame_id_t frame = -1;
  if (!free_list_.empty()) {
    frame = free_list_.front();
    free_list_.pop_front();
  } else {
    replacer_->Victim(&frame);
    if (pages_[frame].IsDirty()) {
      FlushPageImplNoLock(INVALID_PAGE_ID, frame);
    }
  }
  pages_[frame].pin_count_ = 1;
  pages_[frame].is_dirty_ = false;
  *page_id = disk_manager_->AllocatePage();
  pages_[frame].page_id_ = *page_id;
  pages_[frame].ResetMemory();
  latch_.unlock();
  return pages_ + frame;
}

bool BufferPoolManager::DeletePageImpl(page_id_t page_id) {
  // 0.   Make sure you call DiskManager::DeallocatePage!
  // 1.   Search the page table for the requested page (P).
  // 1.   If P does not exist, return true.
  // 2.   If P exists, but has a non-zero pin-count, return false. Someone is using the page.
  // 3.   Otherwise, P can be deleted. Remove P from the page table, reset its metadata and return it to the free list.
  bool ans = true;
  frame_id_t frame;
  // int pin_count = 0;
  latch_.lock();
  for (frame = 0; frame < static_cast<int>(GetPoolSize()); frame++) {
    if (pages_[frame].GetPageId() == page_id) {
      if (pages_[frame].GetPinCount() != 0) {
        // pin_count = pages_[frame].GetPinCount();
        ans = false;
      }
      break;
    }
  }
  if (ans && frame != static_cast<int>(GetPoolSize())) {
    pages_[frame].pin_count_ = 0;
    pages_[frame].page_id_ = INVALID_PAGE_ID;
    pages_[frame].ResetMemory();
    replacer_->Pin(frame);
    free_list_.push_back(frame);
    disk_manager_->DeallocatePage(page_id);
  }
  latch_.unlock();
  // if (!ans) {
  //   LOG_DEBUG("buffer delete page id is %d, pin count is %d", page_id, pin_count);
  //   throw new Exception("delete is bug");
  // }
  return ans;
}

void BufferPoolManager::FlushAllPagesImpl() {
  // You can do it!
  latch_.lock();
  for (size_t i = 0; i < GetPoolSize(); i++) {
    if (pages_[i].GetPageId() != INVALID_PAGE_ID) {
      FlushPageImplNoLock(INVALID_PAGE_ID, i);
    }
  }
  latch_.unlock();
}

void BufferPoolManager::DebugPrint() {
  for (size_t i = 0; i < GetPoolSize(); i++) {
    LOG_DEBUG("pin is %d", pages_[i].GetPinCount());
  }
}
}  // namespace bustub
