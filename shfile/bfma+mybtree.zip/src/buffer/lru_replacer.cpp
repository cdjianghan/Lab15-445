//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_replacer.cpp
//
// Identification: src/buffer/lru_replacer.cpp
//
// Copyright (c) 2015-2019, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/lru_replacer.h"

namespace bustub {

LRUReplacer::LRUReplacer(size_t num_pages) {
  size = 0;
  head = new ListNode(-1);
  tail = new ListNode(-1);
  head->next = tail;
  tail->prev = head;
}

LRUReplacer::~LRUReplacer() {
  for (auto x : victim_map_) {
    delete (x.second);
  }
  delete (head);
  delete (tail);
}

bool LRUReplacer::Victim(frame_id_t *frame_id) {
  latch_.lock();
  if (size == 0U) {
    latch_.unlock();
    return false;
  }
  *frame_id = head->next->frame_id_;
  victim_map_.erase(*frame_id);
  ListNode *node = head->next;
  deleteNode(node);
  latch_.unlock();
  return true;
}

void LRUReplacer::Pin(frame_id_t frame_id) {
  latch_.lock();
  auto iterator = victim_map_.find(frame_id);
  if (iterator != victim_map_.end()) {
    ListNode *node = iterator->second;
    victim_map_.erase(frame_id);
    deleteNode(node);
  }
  latch_.unlock();
}

void LRUReplacer::Unpin(frame_id_t frame_id) {
  latch_.lock();
  auto iterator = victim_map_.find(frame_id);
  if (iterator == victim_map_.end()) {
    ListNode *node = new ListNode(frame_id);
    putTail(node);
    victim_map_[frame_id] = node;
  }
  latch_.unlock();
}

size_t LRUReplacer::Size() { return size; }

void LRUReplacer::deleteNode(ListNode *node) {
  node->prev->next = node->next;
  node->next->prev = node->prev;
  size--;
  delete (node);
}

void LRUReplacer::putTail(ListNode *node) {
  node->next = tail;
  node->prev = tail->prev;
  tail->prev->next = node;
  tail->prev = node;
  size++;
}

}  // namespace bustub
